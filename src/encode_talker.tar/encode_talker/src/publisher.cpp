#include "ros/ros.h"
#include "encode_talker/Encode.h"

int main(int argc, char **argv)
{
    ros::init(argc, argv, "encode_talker");
    ros::NodeHandle n;
    ros::Publisher encode_pub = n.advertise<encode_talker::Encode>("encode", 1);
    ros::Rate loop_rate(10);
    while(n.ok()){
        encode_talker::Encode encode;
        encode.left_vel = 0.111;
        encode.right_vel = 0.222;
        encode_pub.publish(encode);
        ros::spinOnce();
        loop_rate.sleep();
  }
  return 0;
}
